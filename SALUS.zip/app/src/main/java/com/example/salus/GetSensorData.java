package com.example.salus;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class GetSensorData extends Activity{
    TextView hr_num;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
