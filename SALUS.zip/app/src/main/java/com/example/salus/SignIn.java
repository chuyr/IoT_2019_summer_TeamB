package com.example.salus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignIn extends Activity {
    EditText email, pw;
    Button signin, signup, fpw;

    int count = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);

        email = (EditText)findViewById(R.id.email_addr);
        pw = (EditText)findViewById(R.id.password);
        signin = (Button)findViewById(R.id.sign_in);
        signup = (Button)findViewById(R.id.sign_up);
        fpw = (Button)findViewById(R.id.forgotpw);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().equals("admin") &&
                pw.getText().toString().equals("1234")) {
                    Toast.makeText(getApplicationContext(), "Sign in success!", Toast.LENGTH_SHORT).show();
                } else {
                    if(email.getText().toString().length() > 0) {
                        if (pw.getText().toString().length() > 0) {
                            count--;
                            Toast.makeText(getApplicationContext(), "Wrong!\n" + "You can attempt "+ count + "times",
                                    Toast.LENGTH_SHORT).show();

                            if(count == 0) {
                                signin.setEnabled(false);
                                signin.setBackgroundColor(0xC1C1C1);
                                Toast.makeText(getApplicationContext(), "You don't have chance because you attempted 3times.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "You didn't write password. \n" +
                                    "Write your password!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "You didn't write email address. \n" +
                                "Write your email address!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(SignIn.this, SignUp.class);
                startActivity(intent1);
            }
        });

        fpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), ForgotPw.class);
                startActivity(intent2);
            }
        });
    }
}