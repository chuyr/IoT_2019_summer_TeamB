package com.example.salus;

import android.app.Activity;

class TempDrawer extends Activity {

}
