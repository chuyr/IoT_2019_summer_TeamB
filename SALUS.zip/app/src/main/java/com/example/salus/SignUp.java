package com.example.salus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignUp extends Activity {
    EditText firstName, lastName, email, pw, confirm;
    TextView msg;
    Button signUp;

    private boolean isEmpty(EditText etText) {
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        firstName = findViewById(R.id.first_name);
        lastName = findViewById(R.id.last_name);
        email = findViewById(R.id.email_addr);
        pw = findViewById(R.id.password);
        confirm = findViewById(R.id.confirm_password);
        signUp = findViewById(R.id.sign_up);
        msg = findViewById(R.id.sign_up_caution);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEmpty(firstName)) {
                    Toast.makeText(getApplicationContext(), "You didn't write firstName. \n" +
                            "Write your first name!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(lastName)) {
                    Toast.makeText(getApplicationContext(), "You didn't write lastName. \n " +
                            "Write your last name!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "You didn't write email address. \n " +
                            "Write your email address!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(pw)) {
                    Toast.makeText(getApplicationContext(), "You didn't write password. \n " +
                            "Write your password!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(confirm)) {
                    Toast.makeText(getApplicationContext(), "You didn't write confirm. \n " +
                            "Write your confirm!", Toast.LENGTH_SHORT).show();
                } else {
                    msg.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(), "Go to your email box and check email authentication!",
                            Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(60);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Intent signUp_btn = new Intent(SignUp.this, SignIn.class);
                    startActivity(signUp_btn);
                }
            }
        });
    }
}
