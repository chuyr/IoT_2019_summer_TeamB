package com.example.salus;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class sensorList extends Activity {
    ListView sensorList;
    ArrayAdapter<String> registSensor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sensor_listview);

        sensorList = findViewById(R.id.sensor_list);
        sensorList.setAdapter(registSensor);
    }
}
