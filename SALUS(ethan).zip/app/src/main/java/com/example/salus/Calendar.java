package com.example.salus;

import android.app.DatePickerDialog;
import android.app.Dialog;

import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Calendar;

public class MyCalendar extends AppCompatActivity {
    final Calendar myCalendar = Calendar.getInstance();

    EditText edittext= (EditText) findViewById(R.id.select_date);
    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
        @Override
//        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) { 원래 이거였음
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }
    };

    edittext.setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View v) {
            new DatePickerDialog(classname.this, date, myCalendar.get(java.util.Calendar.YEAR),
                    myCalendar.get(java.util.Calendar.MONTH),
                    myCalendar.get(java.util.Calendar.DAY_OF_MONTH)).show();
        }
    });

    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        edittext.setText(sdf.format(myCalendar.getTime()));
    }

   }
