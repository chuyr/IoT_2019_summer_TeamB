//package com.example.salus;
//
//import android.content.Context;
//import android.net.Uri;
//import android.os.Bundle;
//import android.view.InflateException;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import androidx.fragment.app.Fragment;
//
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.MarkerOptions;
//
//
///**
// * A simple {@link Fragment} subclass.
// * Activities that contain this fragment must implement the
// * {@link MapFragment.OnFragmentInteractionListener} interface
// * to handle interaction events.
// * Use the {@link MapFragment#newInstance} factory method to
// * create an instance of this fragment.
// */
//
////@@//
//public class MapFragment extends Fragment implements OnMapReadyCallback {
////@@//
////@@//
//    private float mMapZoomLevel = 15;
//    GpsInfo gpsInfo;
//    GoogleMap mMap;
//    static View view; // 프래그먼트의 뷰 인스턴스
//    Context ctx;
////@@//
//
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
//    private static final String ARG_PARAM2 = "param2";
//
//
//    private String mParam1;
//    private String mParam2;
//
//    private OnFragmentInteractionListener mListener;
//
//    public MapFragment() {
//        // Required empty public constructor
//
//    }
//
//
//    public static MapFragment newInstance(Context ctx) {
//        MapFragment fragment = new MapFragment();
//        Bundle args = new Bundle();
//        fragment.setArguments(args);
//
////@@//
//        fragment.ctx = ctx;
//        fragment.gpsInfo = new GpsInfo(ctx);
//        fragment.gpsInfo.getLocation();
//        if (!fragment.gpsInfo.isGetLocation()) {
//            fragment.gpsInfo.showSettingsAlert();     // GPS setting Alert
//        }
////@@//
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        //@@//
//        try {
//            view = inflater.inflate(R.layout.activity_map, container, false);
//        }catch (InflateException e){
//            e.printStackTrace();
//        }// Inflate the layout for this fragment
//
//        final MapFragment mapFragment = (MapFragment) getActivity().getFragmentManager()
//                .findFragmentById(R.id.fragmentMap);
//        mapFragment.getMapAsync(this);
//
//        return view;
//        //@@//
//    }
//
//    public interface OnFragmentInteractionListener {
//
//        void onFragmentInteraction(Uri uri);
//    }
//
////@@//
//    @Override
//    public void onMapReady(final GoogleMap googleMap) {
//
//        mMap = googleMap;
////        CameraUpdate point = CameraUpdateFactory.newLatLng(new LatLng(32, -127));
//        LatLng location = new LatLng(gpsInfo.getLatitude(), gpsInfo.getLongitude());
//        mMap.addMarker(new MarkerOptions().position(location).title("current location")).setSnippet(String.valueOf(location));
//        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, mMapZoomLevel));
//        mMap.animateCamera(CameraUpdateFactory.zoomTo(mMapZoomLevel));
////        mMap.moveCamera(point);
////        mMap.animateCamera(point);
//    }
////@@//
//
//}
