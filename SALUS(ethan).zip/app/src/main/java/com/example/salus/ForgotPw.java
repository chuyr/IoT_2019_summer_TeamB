package com.example.salus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import static com.example.salus.Movie.getEmail;
import static java.lang.Integer.parseInt;

public class ForgotPw extends Activity {
    EditText email;
    Button ok, cancel;
    String email_address, url, res;

    //REST
    public static final int SUCCESS = 0;
    public static final int INCORRECT_DATA_FORMAT = 1;
    public static final int USER_NOT_EXIST = 2;
    public static String result = "";
    // ~

    private boolean isEmpty(EditText etText) {
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_pw);

        email = findViewById(R.id.email_addr);
        ok = findViewById(R.id.ok_btn);
        cancel = findViewById(R.id.cancel_btn);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // region check email
                if (isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Write your email address!", Toast.LENGTH_SHORT).show();
                }
                //endregion

                //REST
                email_address = getEmail(email);
                url = SignIn.urlBasic + "/pwforgot";

                HttpConnection conn = new HttpConnection();
                JSONObject json = new JSONObject();

                try {
                    json.put("email", email_address);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String forgotPwJson = json.toString();

                try {
                    res = conn.execute(url, forgotPwJson).get();
                    JSONObject json_data = new JSONObject(res);

                    result = (json_data.optString("result"));
                    Log.d("####REST_forgotPw", "result: " + result);
                    switch (parseInt(result)) {
                        case SUCCESS:
                            Toast.makeText(getApplicationContext(), "We send the authentication message to email.\n"
                                    + "Go to check your email box!", Toast.LENGTH_SHORT).show();

                            Intent suc_fpw = new Intent(ForgotPw.this, SignIn.class);
                            startActivity(suc_fpw);
                            break;
                        case INCORRECT_DATA_FORMAT:
                            Toast.makeText(getApplicationContext(),
                                    "Your email address isn't exist.\n Check your email address.", Toast.LENGTH_SHORT).show();
                            break;
                        case USER_NOT_EXIST:
                            Toast.makeText(getApplicationContext(), "You don't have account!!\n" +
                                    "You must register your account! Go to sign up screen.", Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (Exception e) { e.printStackTrace(); }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent click_cancel = new Intent (ForgotPw.this, SignIn.class);
                startActivity(click_cancel);
            }
        });
    }
}
