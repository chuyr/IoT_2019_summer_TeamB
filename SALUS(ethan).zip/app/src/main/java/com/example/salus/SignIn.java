package com.example.salus;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import static com.example.salus.Movie.getEmail;
import static com.example.salus.Movie.getPassword;
import static java.lang.Integer.parseInt;

public class SignIn extends Activity {
    EditText email, pw;
    Button signIn, signUp, fpw;
    int count = Constants.COUNT;
    String email_address, password, url, res;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sp;

    // REST
    public static final int SUCCESS = 0;
    public static final int INCORRECT_DATA_FORMAT = 1;
    public static final int USER_NOT_EXIST = 2;
    public static final int WRONG_PASSWORD = 3;
    public static final int NON_ACTIVE_USER = 4;
    public static final int ALREADY_SIGNED_IN = 5;
    public static String result = "";
    public static String usn = "";
    public static final String urlBasic = "http://teamb-iot.calit2.net/rest/app";
    // ~

    private boolean isEmpty(EditText etText) {      //  check EditText is empty
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);

        email = (EditText)findViewById(R.id.email_addr);
        pw = (EditText)findViewById(R.id.password);
        signIn = (Button)findViewById(R.id.sign_in);
        signUp = (Button)findViewById(R.id.sign_up);
        fpw = (Button)findViewById(R.id.forgotpw);
        sp = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        signIn.setOnClickListener(new View.OnClickListener() {      //  clicked signIn button
            @Override
            public void onClick(View v) {
                // region Email/Password format confirm
                if (!isEmpty(email)) {      //  email address's length > 0 & pw's length == 0
                    if (isEmpty(pw)) {
                        Toast.makeText(getApplicationContext(), "You didn't write password into password format!\n"
                                + "Write your password.", Toast.LENGTH_SHORT).show();
                    }
                }
                else {        //    email address's length == 0 & pw's length > 0
                    if(!isEmpty(pw)) {
                        Toast.makeText(getApplicationContext(), "You didn't write email address. \n" +
                                "Write your email address!", Toast.LENGTH_SHORT).show();
                    }
                }

                SharedPreferences.Editor editor = sp.edit();
                editor.putString(String.valueOf(email), getEmail(email));
                editor.putString(String.valueOf(pw), getPassword(pw));
                // endregion

                // REST
                email_address = getEmail(email);
                password = getPassword(pw);
                url = urlBasic + "/signin";

                HttpConnection conn = new HttpConnection();
                JSONObject Json = new JSONObject();

                try {
                    Json.put("email", email_address);
                    Json.put("password", password);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String signInJson = Json.toString();

                try {
                    res = conn.execute(url, signInJson).get();
                    JSONObject json_data = new JSONObject(res);

                    result = (json_data.optString("result"));
                    usn = (json_data.optString("usn"));
                    Log.d("####REST_signIn", "result: " + result + ", usn: " + usn);

                    switch (parseInt(result)) {
                        case SUCCESS:
                            Toast.makeText(getApplicationContext(), "Sign in success!", Toast.LENGTH_SHORT).show();

                            Intent suc_signin = new Intent(SignIn.this, Main.class);        //  sign
                            startActivity(suc_signin);
                            break;

                        case INCORRECT_DATA_FORMAT:
                            Toast.makeText(getApplicationContext(),
                                    "Your email address or password mismatched format", Toast.LENGTH_SHORT).show();
                            break;

                        case USER_NOT_EXIST:
                            Toast.makeText(getApplicationContext(), "You don't have account!!\n" +
                                    "You must register your account! Go to sign up screen.", Toast.LENGTH_SHORT).show();
                            break;

                        case WRONG_PASSWORD:
                            count--;
                            Toast.makeText(getApplicationContext(), "Wrong!\n" + "You didn't match password format!\n"
                                    + "You can attempt " + count + "times", Toast.LENGTH_SHORT).show();

                            if (count == 0) {        // no attempt chance
                                signIn.setEnabled(false);
                                signIn.setBackgroundColor(0xC1C1C1);
                                Toast.makeText(getApplicationContext(),
                                        "You don't have chance because you attempted 10times.", Toast.LENGTH_SHORT).show();
                            }
                            break;

                        case NON_ACTIVE_USER:
                            Toast.makeText(getApplicationContext(), "You didn't authenticate to email yet." +
                                    "Check your email box.", Toast.LENGTH_SHORT).show();
                            break;

                        case ALREADY_SIGNED_IN:
                            Toast.makeText(getApplicationContext(), "You already signed in." +
                                    "Don't hack.", Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //  ~
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {      //  clicked signUp button
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(SignIn.this, SignUp.class);
                startActivity(intent1);
            }
        });

        fpw.setOnClickListener(new View.OnClickListener() {     //  clicked ForgottonPassword button
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), ForgotPw.class);
                startActivity(intent2);
            }
        });
    }
}