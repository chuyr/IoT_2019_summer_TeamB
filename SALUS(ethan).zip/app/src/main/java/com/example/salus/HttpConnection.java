package com.example.salus;

import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpConnection extends AsyncTask<String, Integer, String> {

    @Override
    protected String doInBackground(String... inputs) {

        String urlString = inputs[0];
        String msg = inputs[1];
        String resultString;
        try {
            URL url = new URL(urlString);
            resultString = uploadUrl(url, msg);
            Log.d("####", "url : " + url + " msg : " + msg);
            Log.d("####", "resultString : " + resultString);
            if (resultString == "") {
                throw new IOException("No response received.");
            }
        } catch (Exception e) {
            return "exception!";
        }
        return resultString;
    }

    private String uploadUrl(URL url, String msg) {
        int serverResponseCode = 0;
        String result = "";

        try {
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
           //   url connection setting
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept-Charset", "euc-kr");
            conn.setRequestProperty("Context_Type", "application/json");

            OutputStream os = conn.getOutputStream();
            byte [] osBytes = msg.getBytes("euc-kr");
            os.write(osBytes, 0, osBytes.length);

            os.flush();
            os.close();

            InputStream is = conn.getInputStream();

            result = readStream(is, 512);

            serverResponseCode = conn.getResponseCode();
        } catch (MalformedURLException e) {
            Log.e(this.getClass().getName(),e.toString());
        } catch (IOException e) {
            Log.e(this.getClass().getName(),e.toString());
        } catch (Exception e){
        }

        return result;
    }

    public String readStream(InputStream is, int maxReadSize)
            throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(is, "UTF-8");

        char[] rawBuffer = new char[maxReadSize];
        int readSize;
        StringBuffer buffer = new StringBuffer();
        while (((readSize = reader.read(rawBuffer)) != -1) && maxReadSize > 0) {
            if (readSize > maxReadSize) {
                readSize = maxReadSize;
            }
            buffer.append(rawBuffer, 0, readSize);
            maxReadSize -= readSize;
        }
        return buffer.toString();
    }

//      나중에 압축풀기
//        protected void onProgressUpdate(Integer... progress) {
//            setProgressPercent(progress[0]);
//        }
//
//        protected void onPostExecute(Long result) {
//            showDialog("Uploaded " + result + " bytes");
//        }
}
