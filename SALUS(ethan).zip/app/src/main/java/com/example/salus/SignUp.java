package com.example.salus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import static com.example.salus.Movie.getEmail;
import static com.example.salus.Movie.getFirstName;
import static com.example.salus.Movie.getLastName;
import static com.example.salus.Movie.getPassword;
import static java.lang.Integer.parseInt;

public class SignUp extends Activity {
    EditText firstName, lastName, email, pw, confirm;
    TextView msg;
    Button signUp;
    String fName, lName, email_address, password, url, res;

    // REST
    public static final int SUCCESS = 0;
    public static final int FORMAT_ERROR = 1;
    public static final int EXIST_EMAIL = 2;
    public static String result = "";
    // ~

    private boolean isEmpty(EditText etText) {      //  check EditText is empty
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        firstName = findViewById(R.id.first_name);
        lastName = findViewById(R.id.last_name);
        email = findViewById(R.id.email_addr);
        pw = findViewById(R.id.password);
        confirm = findViewById(R.id.confirm_password);
        signUp = findViewById(R.id.sign_up);
        msg = findViewById(R.id.sign_up_caution);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // region signUp's data format check
                if (isEmpty(firstName)) {
                    Toast.makeText(getApplicationContext(), "You didn't write firstName. \n" +
                            "Write your first name!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(lastName)) {
                    Toast.makeText(getApplicationContext(), "You didn't write lastName. \n " +
                            "Write your last name!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "You didn't write email address. \n " +
                            "Write your email address!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(pw)) {
                    Toast.makeText(getApplicationContext(), "You didn't write password. \n " +
                            "Write your password!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(confirm) && (pw.getText().toString() != confirm.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "You didn't write confirm. \n " +
                            "Write your confirm!", Toast.LENGTH_SHORT).show();
                }
                //endregion

                //REST
                fName = getFirstName(firstName);
                lName = getLastName(lastName);
                email_address = getEmail(email);
                password = getPassword(pw);
                url = SignIn.urlBasic + "/signup";
                Log.d("####URL", url);

                HttpConnection conn = new HttpConnection();
                JSONObject json = new JSONObject();

                try {
                    json.put("email", email_address);
                    json.put("password", password);
                    json.put("first-name", fName);
                    json.put("last-name", lName);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String signUpJson = json.toString();

                try {
                    res = conn.execute(url, signUpJson).get();
                    JSONObject json_data = new JSONObject(res);

                    result = (json_data.optString("result"));
                    Log.d("####REST_signUp", "result: " + result);

                    switch (parseInt(result)) {
                        case SUCCESS:
                            msg.setVisibility(View.VISIBLE);

                            Toast.makeText(getApplicationContext(), "Go to your email box and check email authentication!",
                                    Toast.LENGTH_SHORT).show();

                            try {
                                Thread.sleep(300);
                            } catch (InterruptedException e) { e.printStackTrace(); }

                            Intent signUp_btn = new Intent(SignUp.this, SignIn.class);
                            startActivity(signUp_btn);
                            break;
                        case FORMAT_ERROR:
                            Toast.makeText(getApplicationContext(),
                                    "Your email address or password mismatched format", Toast.LENGTH_SHORT).show();
                            break;
                        case EXIST_EMAIL:
                            Toast.makeText(getApplicationContext(), "You have account!!\n" +
                                    "You can sign in our program!", Toast.LENGTH_SHORT).show();
                            break;
                    }
                } catch (ExecutionException | InterruptedException | JSONException e) {
                    e.printStackTrace();
                }
                //  ~
            }
        });
    }
}
