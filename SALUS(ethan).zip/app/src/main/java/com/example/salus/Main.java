package com.example.salus;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import static com.example.salus.Movie.getPassword;
import static java.lang.Integer.parseInt;

public class Main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    String password, url, res, res1;
    TextView heartRate;
    Button graphBtn, mapBtn;
    private String readBluetoothMsg = "";
    ArrayAdapter<String> SensorName;
    ArrayAdapter<String> SensorMAC;

    // REST
    public static final int SUCCESS = 0;
    public static String result = "";
    public static String ssn = "";
    public static String registered = "";
    public static int usn = 0;
    public static int type = 0;
    public static String mac = "";
    public static final int TYPE_UDOO = 0;
    public static final int TYPE_POLAR = 1;
    //  ~

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_drawer);

        heartRate = findViewById(R.id.hr_num);
        graphBtn = findViewById(R.id.graph_btn);
        mapBtn = findViewById(R.id.map_btn);

        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            BluetoothChatFragment fragment = new BluetoothChatFragment();
            transaction.replace(R.id.sample_content_fragment, fragment);
            transaction.commit();
        }

//        navigation bar 문제 있을 경우 제거할 것
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        activatePolar();

        graphBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("####", "graph button click!");
                Toast.makeText(getApplicationContext(), "graph button click!", Toast.LENGTH_SHORT).show();
                Intent graphScreen = new Intent(Main.this, Graph.class);
                startActivity(graphScreen);
            }
        });

//        mapBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d("####", "map button click!");
//                Toast.makeText(getApplicationContext(), "map button click!", Toast.LENGTH_SHORT).show();
//                Intent mapScreen = new Intent(Main.this, MapFragment.class);
//                startActivity(mapScreen);
//            }
//        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //  pressed back button into main screen if you want to exit app
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            final AlertDialog.Builder appQuit = new AlertDialog.Builder(Main.this);
            appQuit.setTitle("S A L U S");
            appQuit.setMessage("Do you want to exit and sign out ?");
            appQuit.setCancelable(false);
            appQuit.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface DI, int which) {
                   //  REST
                   usn = parseInt(SignIn.usn);
                   url = SignIn.urlBasic + "/signout";
                   final int USER_NOT_EXIST = 1;
                   final int ALREADY_LOGGED_OUT = 2;

                   HttpConnection conn = new HttpConnection();
                   JSONObject json = new JSONObject();
                   try {
                       json.put("usn", usn);
                   } catch (JSONException e) { e.printStackTrace(); }

                   String signOutJson = json.toString();
                   try {
                       res = conn.execute(url, signOutJson).get();
                       JSONObject json_data = new JSONObject(res);

                       result = (json_data.optString("result"));
                       Log.d("####REST_signOut", "result: " + result);

                       switch (parseInt(result)) {
                           case SUCCESS:
                               Toast.makeText(getApplicationContext(), "You successfully signed out.",
                                       Toast.LENGTH_SHORT).show();
                               break;
                           case USER_NOT_EXIST:
                               Toast.makeText(getApplicationContext(), "Don't hack!", Toast.LENGTH_SHORT).show();
                               break;
                           case ALREADY_LOGGED_OUT:
                               Toast.makeText(getApplicationContext(), "You already signed out", Toast.LENGTH_SHORT).show();
                               break;
                       }
                   } catch (InterruptedException | ExecutionException e) {
                       e.printStackTrace();
                   } catch (JSONException e) {
                       e.printStackTrace();
                   }
                   //  ~
                   Log.d("####", "signed out through exit button");
                   finishAffinity();
                   System.runFinalization();
                   System.exit(0);
               }
            });
            appQuit.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface DI, int which) {
                    DI.cancel();
                }
            });
            AlertDialog alertExit = appQuit.create();
            alertExit.show();
        }
        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.user_info) {
            // Handle action
        } else if (id == R.id.change_pw) {
            Intent changePwd = new Intent(Main.this, changePw.class);
            startActivity(changePwd);
        } else if (id == R.id.add_contact) {
            //  add people email to contact
        } else if (id == R.id.delete_account) {
            //create the object of AlertDialog Builder class
            final AlertDialog.Builder builder = new AlertDialog.Builder(Main.this);
            //set the message show for the alert time
            builder.setMessage("Once you delete your account, there is no going back. " +
                    "Be certain. Are you sure ?");
            //set Alert title
            builder.setTitle("Delete account");
            //set cancelable false
            //for when the user clicks on the outside
            //the Dialog box then it will remain show
            builder.setCancelable(false);

            final EditText input = new EditText(Main.this);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

            //set the positive button with yes name
            //OnClickListener method is use of DialogInterface interface.
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //When the user click yes button
                    //then user's account delete
                    final AlertDialog.Builder check = new AlertDialog.Builder(Main.this);
                    check.setTitle("Delete account");
                    check.setMessage("Enter your password..");
                    check.setView(input);
                    check.setCancelable(false);
                    check.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //  REST
                            usn = parseInt(SignIn.usn);
                            password = getPassword(input);
                            url = SignIn.urlBasic + "/idcancel";

                            HttpConnection conn = new HttpConnection();
                            JSONObject json = new JSONObject();

                            try {
                                json.put("usn", usn);
                                json.put("password", password);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            String idCancelJson = json.toString();

                            final int INCORRECT_DATA_FORMAT = 1;
                            final int USER_NOT_EXIST = 2;
                            final int SIGNED_OUT_USER = 3;
                            final int WRONG_PASSWORD= 4;

                            try {
                                res = conn.execute(url, idCancelJson).get();
                                JSONObject json_data = new JSONObject(res);

                                result = (json_data.optString("result"));
                                Log.d("####REST_idCancel", "result: " + result);

                                switch (parseInt(result)) {
                                    case SUCCESS:
                                        Toast.makeText(getApplicationContext(), "Your account successfully deleted.\n" +
                                                "ByeBye!", Toast.LENGTH_SHORT).show();
                                        Intent suc_idcan = new Intent(Main.this, SignIn.class);
                                        startActivity(suc_idcan);
                                        break;
                                    case INCORRECT_DATA_FORMAT:
                                        Toast.makeText(getApplicationContext(), "You mismatched password format.\n" +
                                                "Enter password again!", Toast.LENGTH_SHORT).show();
                                        break;
                                    case USER_NOT_EXIST:
                                        Toast.makeText(getApplicationContext(), "Are your sure you have account ?\n" +
                                                "Don't hack!", Toast.LENGTH_SHORT).show();

                                        Intent fail_idcan = new Intent(Main.this, SignIn.class);
                                        startActivity(fail_idcan);
                                        break;
                                    case SIGNED_OUT_USER:
                                        Toast.makeText(getApplicationContext(), "You already signed out.", Toast.LENGTH_SHORT).show();

                                        Intent fail_idcan1 = new Intent(Main.this, SignIn.class);
                                        startActivity(fail_idcan1);
                                        break;
                                    case WRONG_PASSWORD:
                                        Toast.makeText(getApplicationContext(), "You putted wrong password.\n" +
                                                "Check your password!", Toast.LENGTH_SHORT).show();
                                        break;
                                }
                            } catch(ExecutionException | InterruptedException e) {
                                e.printStackTrace();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            //  ~
                        }
                    });
                    check.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();

                            Toast.makeText(Main.this, "You failed to delete your account.\n", Toast.LENGTH_SHORT).show();
                        }
                    });
                    AlertDialog alertPW = check.create();
                    alertPW.show();
                }
            });

            //set the negative button with no name
            //OnClickListener method is use of DialogInterface interface.
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //If user click no
                    //then dialog box is canceled.
                    dialog.cancel();
                }
            });

            //create the alert dialog
            AlertDialog alertDialog = builder.create();
            //show the alert dialog box
            alertDialog.show();
        } else if (id == R.id.history_hr) {

        } else if (id == R.id.history_air) {

        } else if (id == R.id.sensor_list) {
            //  REST
            usn = parseInt(SignIn.usn);
            url = SignIn.urlBasic + "/sensor_reg_asso";
            SensorName = DeviceListActivity.SensorName;
            SensorMAC = DeviceListActivity.SensorMAC;
            final int INCORRECT_SENSOR_TYPE = 1;
            final int INCORRECT_MAC_ADDRESS_FORMAT = 2;
            final int USER_NOT_EXIST = 3;
            final int SIGNED_OUT_USER = 4;
            final int SENSOR_ALREADY_OWNED_BY_OTHER_USER = 5;

            HttpConnection conn = new HttpConnection();
            JSONObject json = new JSONObject();

            for (int i = 0; i < SensorName.getCount(); i++) {
                if (SensorName.getItem(i).contains("DESKTOP")) {
                    String target = String.valueOf(SensorName.getItem(i).contains("DESKTOP"));
                    SensorName.remove(target);
                    SensorMAC.remove(target);
                } else if (SensorName.getItem(i).contains("Galaxy")) {
                    String target = String.valueOf(SensorName.getItem(i).contains("Galaxy"));
                    SensorName.remove(target);
                    SensorMAC.remove(target);
                }
                Log.d("####", "paired devices: " + SensorName.getItem(i));
            }

            for (int i = 0; i  < SensorMAC.getCount(); i++) {
                if (SensorName.getItem(i).contains("Polar")) {
                    type = TYPE_POLAR;
                    mac = SensorMAC.getItem(i);

                    try {
                        json.put("usn", usn);
                        json.put("type", type);
                        json.put("mac", mac);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        String RegistPolarJson = json.toString();
                        res = conn.execute(url, RegistPolarJson).get();
                        JSONObject json_data = new JSONObject(res);

                        result = (json_data.optString("result"));
                        ssn = (json_data.optString("ssn"));
                        registered = (json_data.optString("registered"));
                        Log.d("####REST_registSensor", "result: " + result + ", ssn: " + ssn
                                + ", registered: " + registered);

                        switch (parseInt(result)) {
                            case SUCCESS:
                                Toast.makeText(getApplicationContext(), "You successfully register sensor.",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case INCORRECT_SENSOR_TYPE:
                                Toast.makeText(getApplicationContext(), "Wrong sensor type.", Toast.LENGTH_SHORT).show();
                                break;
                            case INCORRECT_MAC_ADDRESS_FORMAT:
                                Toast.makeText(getApplicationContext(), "Wrong your sensor MAC address type.", Toast.LENGTH_SHORT).show();
                                break;
                            case USER_NOT_EXIST:
                                Toast.makeText(getApplicationContext(), "Your account doesn't exist.\n" +
                                        "How to sign in ?", Toast.LENGTH_SHORT).show();
                                break;
                            case SIGNED_OUT_USER:
                                Toast.makeText(getApplicationContext(), "You already signed out.\n" +
                                        "Don't click back button!", Toast.LENGTH_SHORT).show();
                                break;
                            case SENSOR_ALREADY_OWNED_BY_OTHER_USER:
                                Toast.makeText(getApplicationContext(), "You don't use this sensor.\n" +
                                        "Use other sensor!", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                else if (SensorName.getItem(i).contains("udoo")){
                    HttpConnection conn1 = new HttpConnection();
                    JSONObject json1 = new JSONObject();

                    type = TYPE_UDOO;
                    mac = SensorMAC.getItem(i);

                    try {
                        json1.put("usn", usn);
                        json1.put("type", type);
                        json1.put("mac", mac);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        String RegistUdooJson = json1.toString();
                        res1 = conn1.execute(url, RegistUdooJson).get();
                        JSONObject json_data = new JSONObject(res1);

                        result = (json_data.optString("result"));
                        ssn = (json_data.optString("ssn"));
                        registered = (json_data.optString("registered"));
                        Log.d("####REST_registSensor", "result: " + result + ", ssn: " + ssn
                                + ", registered: " + registered);

                        switch (parseInt(result)) {
                            case SUCCESS:
                                Toast.makeText(getApplicationContext(), "You successfully register sensor.",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case INCORRECT_SENSOR_TYPE:
                                Toast.makeText(getApplicationContext(), "Wrong sensor type.", Toast.LENGTH_SHORT).show();
                                break;
                            case INCORRECT_MAC_ADDRESS_FORMAT:
                                Toast.makeText(getApplicationContext(), "Wrong your sensor MAC address type.", Toast.LENGTH_SHORT).show();
                                break;
                            case USER_NOT_EXIST:
                                Toast.makeText(getApplicationContext(), "Your account doesn't exist.\n" +
                                        "How to sign in ?", Toast.LENGTH_SHORT).show();
                                break;
                            case SIGNED_OUT_USER:
                                Toast.makeText(getApplicationContext(), "You already signed out.\n" +
                                        "Don't click back button!", Toast.LENGTH_SHORT).show();
                                break;
                            case SENSOR_ALREADY_OWNED_BY_OTHER_USER:
                                Toast.makeText(getApplicationContext(), "You don't use this sensor.\n" +
                                        "Use other sensor!", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            //  ~
            Intent sensorList = new Intent(Main.this, sensorList.class);
            startActivity(sensorList);

        } else if (id == R.id.sign_out) {
            //create the object of AlertDialog Builder class
            AlertDialog.Builder builder = new AlertDialog.Builder(Main.this);

            //set the message show for the alert time
            builder.setMessage("Do you want to sign out ?");
            //set Alert title
            builder.setTitle("Sign out");
            //set cancelable false
            //for when the user clicks on the outside
            //the Dialog box then it will remain show
            builder.setCancelable(false);
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences sp = getSharedPreferences(SignIn.MyPREFERENCES, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    editor.clear();
                    editor.commit();

                    //  REST
                    usn = parseInt(SignIn.usn);
                    url = SignIn.urlBasic + "/signout";
                    final int USER_NOT_EXIST = 1;
                    final int ALREADY_LOGGED_OUT = 2;

                    HttpConnection conn = new HttpConnection();
                    JSONObject json = new JSONObject();
                    try {
                        json.put("usn", usn);
                    } catch (JSONException e) { e.printStackTrace(); }

                    String signOutJson = json.toString();
                    try {
                        res = conn.execute(url, signOutJson).get();
                        JSONObject json_data = new JSONObject(res);

                        result = (json_data.optString("result"));
                        Log.d("####REST_signOut", "result: " + result);

                        switch (parseInt(result)) {
                            case SUCCESS:
                                Toast.makeText(getApplicationContext(), "You successfully signed out.",
                                        Toast.LENGTH_SHORT).show();

                                Intent suc_so = new Intent(Main.this, SignIn.class);
                                startActivity(suc_so);
                                break;
                            case USER_NOT_EXIST:
                                Toast.makeText(getApplicationContext(), "Don't hack!", Toast.LENGTH_SHORT).show();

                                Intent fail_so = new Intent(Main.this, SignIn.class);
                                startActivity(fail_so);
                                break;
                            case ALREADY_LOGGED_OUT:
                                Toast.makeText(getApplicationContext(), "You already signed out", Toast.LENGTH_SHORT).show();

                                Intent fail_so1 = new Intent(Main.this, SignIn.class);
                                startActivity(fail_so1);
                                break;
                        }
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    //  ~
                }
            });

            //set the negative button with no name
            //OnClickListener method is use of DialogInterface interface.
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //If user click no
                    //then dialog box is canceled.
                    dialog.cancel();

                }
            });

            //create the alert dialog
            AlertDialog alert = builder.create();
            //show the alert dialog box
            alert.show();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private final MyPolarBleReceiver mPolarBleUpdateReceiver = new MyPolarBleReceiver() {};

    public void displayHR(int hr) {
        heartRate.setText(hr + "bpm");
    }

//    public void getAirData(String readMsg) throws JSONException {
//        JSONObject json_data = new JSONObject(readMsg);
//        readBluetoothMsg = (json_data.optString("pm"));
//    }

    protected void activatePolar() {
        Log.w(this.getClass().getName(), "activatePolar()");
        registerReceiver(mPolarBleUpdateReceiver, makePolarGattUpdateIntentFilter());
        mPolarBleUpdateReceiver.sendCaller(this);
    }

    protected void deactivatePolar() {
        unregisterReceiver(mPolarBleUpdateReceiver);
    }

    private static IntentFilter makePolarGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MyPolarBleReceiver.ACTION_GATT_CONNECTED);
        intentFilter.addAction(MyPolarBleReceiver.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(MyPolarBleReceiver.ACTION_HR_DATA_AVAILABLE);
        return intentFilter;
    }
}
