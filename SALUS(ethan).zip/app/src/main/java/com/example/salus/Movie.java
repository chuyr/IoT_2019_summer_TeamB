package com.example.salus;

import android.widget.EditText;

public class Movie {
    private static String email_address;
    private static String pw;
    private static String fName;
    private static String lName;
    private static String npw;

    public static String getEmail(EditText email) {
        email_address = email.getText().toString();
        return email_address;
    }

    public static String getPassword(EditText password) {
        pw = password.getText().toString();
        return pw;
    }

    public static String getFirstName(EditText firstName) {
        fName = firstName.getText().toString();
        return fName;
    }

    public static String getLastName(EditText lastName) {
        lName = lastName.getText().toString();
        return lName;
    }

    public static String getNewPassword(EditText nPassword) {
        npw = nPassword.getText().toString();
        return npw;
    }
}
