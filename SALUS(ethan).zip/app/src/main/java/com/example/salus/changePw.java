package com.example.salus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

import static com.example.salus.Movie.getNewPassword;
import static com.example.salus.Movie.getPassword;
import static java.lang.Integer.parseInt;

public class changePw extends Activity {
    EditText cpw, npw, confirm;
    Button btn;
    String cPw, nPw, url, res;

    // REST
    public static final int SUCCESS = 0;
    public static final int INCORRECT_DATA_FORMAT = 1;
    public static final int USER_NOT_EXIST = 2;
    public static final int SIGNED_OUT_USER = 3;
    public static final int INCORRECT_CURRENT_PASSWORD= 4;
    public static String result = "";
    public static int usn = 0;
    //  ~

    private boolean isEmpty(EditText etText) {
        if (etText.getText().toString().trim().length() > 0)
            return false;
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_pw);

        cpw = findViewById(R.id.current_pw);
        npw = findViewById(R.id.new_pw);
        confirm = findViewById(R.id.confirm_pw);
        btn = findViewById(R.id.complete);

        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // region change password process
                if (isEmpty(cpw)) {
                    Toast.makeText(getApplicationContext(), "You didn't current password.\n" +
                            "Enter your current password!", Toast.LENGTH_SHORT).show();
                } else if (isEmpty(npw)) {
                    Toast.makeText(getApplicationContext(), "You didn't new password.\n" +
                            "Enter your new password!", Toast.LENGTH_SHORT).show();
                }
                else if (isEmpty(confirm) && (npw.getText().toString() != confirm.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "You didn't confirm.\n" +
                            "Enter your confirm!", Toast.LENGTH_SHORT).show();
                }
                // endregion

                //  REST
                usn = parseInt(SignIn.usn);
                cPw = getPassword(cpw);
                nPw = getNewPassword(npw);
                url = SignIn.urlBasic + "/pwchange";

                HttpConnection conn = new HttpConnection();
                JSONObject json = new JSONObject();

                try {
                    json.put("usn", usn);
                    json.put("cur-password", cPw);
                    json.put("new-password", nPw);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String changePwJson = json.toString();

                try {
                    res = conn.execute(url, changePwJson).get();
                    JSONObject json_data = new JSONObject(res);

                    result = (json_data.optString("result"));
                    Log.d("####REST_changePw", "result: " + result);

                    switch(parseInt(result)) {
                        case 0:
                            Toast.makeText(getApplicationContext(), "You successfully changed password.\n"
                                    + "Please sign out!", Toast.LENGTH_SHORT).show();

                            Intent suc_fpw = new Intent(changePw.this, Main.class);
                            startActivity(suc_fpw);
                            Log.d("####REST_changePw", "result code: success");
                            break;
                        case INCORRECT_DATA_FORMAT:
                            Toast.makeText(getApplicationContext(), "You mismatched current password or new password.\n"
                                    + "Enter input again!", Toast.LENGTH_SHORT).show();
                            Log.d("####REST_changePw", "result code: INCORRECT_DATA_FORMAT");
                            break;
                        case USER_NOT_EXIST:
                            Toast.makeText(getApplicationContext(), "Do you have account ?\n"
                                    + "Don't hack", Toast.LENGTH_SHORT).show();

                            Intent fail_fpw = new Intent(changePw.this, SignIn.class);
                            startActivity(fail_fpw);
                            Log.d("####REST_changePw", "result code: USER_NOT_EXIST");
                            break;
                        case SIGNED_OUT_USER:
                            Toast.makeText(getApplicationContext(), "You already signed out.\n"
                                    + "Don't hack", Toast.LENGTH_SHORT).show();

                            Intent fail_fpw1 = new Intent(changePw.this, SignIn.class);
                            startActivity(fail_fpw1);
                            Log.d("####REST_changePw", "result code: SIGNED_OUT_USER");
                            break;
                        case INCORRECT_CURRENT_PASSWORD:
                            Toast.makeText(getApplicationContext(), "You entered wrong current password.\n"
                                    + "Enter input again!", Toast.LENGTH_SHORT).show();
                            Log.d("####REST_changePw", "result code: INCORRECT_CURRENT_PASSWORD");
                            break;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //  ~
            }
        });
    }
}
